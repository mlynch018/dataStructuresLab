#include<iostream>
#include<string>

using std::cout;
using std::endl;
using std::cin;
using std::string;

int main() 
{
  string s;

  while (cin)
  {      
    getline(cin,s);
    if (s[0]!='#')
      cout<<s<<endl;
  } 

  return 0;
}

