#!/bin/bash

if (($#>2));then
  echo "You can not enter more than two inputs"
elif (($#<2));then 
  echo "You can not enter less than two inputs"
else 
  echo "Look for \""$1"\" on the specified web page"
  wget $2 --quiet
  holdAns=$(grep $1 index.html | wc -l)
  echo $1":"$holdAns
  exit 0
fi
