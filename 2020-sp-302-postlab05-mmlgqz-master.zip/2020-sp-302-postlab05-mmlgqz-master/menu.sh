#!/bin/bash

show_menu()
{
  for file in *

  do 

  echo ""	  

  echo "v) View" $file
  echo "e) Edit" $file
  echo "c) Compile" $file
  echo "x) Execute" $file
  echo "q) Quit"

  read ini
  
  case $ini in

  v)
    less $file
  ;;
  e) 
    vim $file
  ;;
  c)
    g++ $file
  ;;
  x)
    ./$file
  ;;
  q)
    exit
  ;;
  *)
    echo "INVALID RESPONSE"
    echo ""
    echo "Skipping this file"
  ;;


  esac
  done  

}

show_menu
