#include "catch.hpp"
#include "list.h"

TEST_CASE("List Empty","[list]")
{
  List<int> temp;
  
  SECTION("An empty list returns one")
  {
    CHECK(temp.empty()==1);
    temp.append(1);
    CHECK(temp.empty()==0);
  }

  SECTION("A copied list will also be empty")
  {
    List<int> copy(temp);
    CHECK(!temp.empty());
    temp.pop();
    List<int> copy2(temp);
    CHECK(copy2.empty());
  }
}

TEST_CASE("List Length", "[list]")
{
  List<int> temp;
  
  SECTION("List has correct length")
  {
    CHECK(temp.length()==0);
    temp.append(1);
    CHECK(temp.length()==1);
  }

  SECTION("A Copied List is the same length")
  {
    List<int> copy(temp);
    CHECK(temp.length()==copy.length());
  }

  for (int i=0; i<10; i++)
    temp.append(i);

  SECTION("A copied list has the same length")
  {
    List<int> copy(temp);
    CHECK(temp.length()==copy.length());
  }
}

TEST_CASE("List elements","[list]")
{
  List<int> temp;
  List<int> temp2;

  for (int i=0; i<10; i++)
    temp.append(i);

  for (int i=10; i>0; i--)
    temp2.prepend(i);

  SECTION("Elements added with append are accessible")
  {
    for (int i=0; i<10; i++)
      CHECK(temp[i]=i);
  }

  SECTION("Elements added with prepend are accessible")
  {
    for (int i=0; i<10; i++)
      CHECK(temp2[i]==i);
  }

  SECTION("A copied list is identical")
  {
    List <int> copy(temp);
    for (int i=0; i<temp.length(); i++)
      CHECK(temp[i]==temp2[i]);
  }

  SECTION("List copies are deep copies")
  {
    List<int> copy(temp);
    for (int i=0; i<temp.length(); i++)
    {
      copy[i]=-1;
      CHECK(temp[i]!=copy[i]);
    }
  }

  SECTION("Elements popped are removed")
  {
    for (int i=0; i<10; i++)
      temp.pop();
    CHECK(temp.empty()==1);
    CHECK(temp.length()==0);
  }

  SECTION("Out-of-bounds accesses are detected")
  {
    List <int> l;
    
    for (int i=0; i<15; i++)
      l.prepend(i);

    for (int i=0; i<15; i++)
      l.pop();

    CHECK_THROWS_WITH(l.pop(),"empty list");
  }
}

TEST_CASE("List accessors", "[list]")
{
  List <int> temp;
  
  for (int i=0; i<10; i++)
    temp.append(i);

  SECTION("head correct")
  {
    CHECK(temp.head()==0);
  }

  SECTION("tail correct")
  {
    List<int> copy(temp);
    CHECK(copy.tail()==1);
    temp.pop();
  }
}
